print("hello world")

input("press to exit")